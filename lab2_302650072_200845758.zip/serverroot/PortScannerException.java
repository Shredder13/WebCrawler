public class PortScannerException extends Exception {
	
	private static final long serialVersionUID = 13206502066090132L;

	public PortScannerException(String error) {
		super(error);
	}
}