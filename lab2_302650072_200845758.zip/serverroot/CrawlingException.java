public class CrawlingException extends Exception {
	
	private static final long serialVersionUID = -8869984155676772366L;

	public CrawlingException(String error) {
		super(error);
	}
}
